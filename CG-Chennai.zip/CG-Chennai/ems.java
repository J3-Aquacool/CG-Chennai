class Employee
{

int eid;
String ename;
String location;

Address address;

 Employee(int eid,String ename,String location,Address address)
{
this.eid= eid;
this.ename= ename;
this.location=location;
this.address=address;

}
public String toString()
{
return eid+" "+ename+ " "+location + " "+address;
}
/*public void setAddress(Address address)
{
this.address=address;
}

public Address getAddress()
{

return address;
}
*/

}




class Address
{

String lmark;
int pincode;
String city;

Address(String lmark,int pincode,String city)
{
this.lmark=lmark;
this.pincode=pincode;
this.city=city;

}

public String toString()
{
return lmark +" "+pincode +" "+city;
}


}

class ems
{

public static void main(String a[])
{
//Address address=new Address("Sipcot",603103,"Chennai");

Employee emp=new Employee(10,"Shwetha","Chennai",new Address("Sipcot",603103,"Chennai"));

//emp.setAddress(address);

System.out.println(emp);

}
}




//
