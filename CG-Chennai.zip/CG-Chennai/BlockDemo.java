

class BlockDemo
{

	{

		System.out.println("Inside No-Name Block");
	}





public static void main(String a[])
{
BlockDemo d=new BlockDemo();

System.out.println("Inside Main block");


}

static
{

System.out.println("Static block");
}


}
