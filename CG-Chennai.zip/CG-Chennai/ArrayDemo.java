class ArrayDemo  
{
	
	public static void main(String[] args) 
	{
	
//Array declartions in Java
//int numArr[]={1,3,6,7};
//int numArr[]=new int[10];
int []numArr={1,4,5,5};


 
	}
}
