class TypeCasting
{



public static void main(String a[])
{

//int a=10;


float f=10.4f;

int x=(int)f;
System.out.println(x);

char c='A';
int data=c;
System.out.println(data); implicti casting


}



}