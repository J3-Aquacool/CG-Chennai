









class Account
{


//acess specifiers: private
private int acno;
private String name;
private int amount;
private float roi=105f;
private void calculateBalance(int amount)
{
System.out.println(" Total Balance :"+amount);

}

// abstraction : what needs to be exposed / public view 


public 	void setName(String name)
{
this.name=name;
}

public void  setAmount(int amount)
{

calculateBalance(amount);

this.amount=amount;
}



public int getAmount()
{



return amount;



}

public String getName()
{
return name;
}

}

class demo
{

public static void main(String a[])
{

Account ac=new Account();

ac.setName("Shivaranjini");
ac.setAmount(777777);

//ac.calculateBalance(66666);

System.out.println(ac.getName());
System.out.println(ac.getAmount());
}
}
