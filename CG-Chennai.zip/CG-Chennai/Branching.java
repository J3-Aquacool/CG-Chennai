
class BranchingDemo
{


public static void main(String a[])
{
// using break


// Initially loop is set to run from 0-9 
        for (int i = 0; i < 10; i++) 
        { 
            // terminate loop when i is 5. 
            if (i == 5) 
                break; 
  
            System.out.println("i: " + i); 
        } 
        System.out.println("Loop complete."); 
// using contniue
for (int i = 0; i < 10; i++) 
        { 
            // If the number is even 
            // skip and continue 
            if (i%2 == 0) 
                continue; 
              // If number is odd, print it 
            System.out.print(i + " "); 
        } 
// using return 
boolean t = true; 
        System.out.println("Before the return."); 
              if (t) 

            return; 
          // Compiler will bypass every statement          // after return 
        System.out.println("This won't execute."); 
}

}
