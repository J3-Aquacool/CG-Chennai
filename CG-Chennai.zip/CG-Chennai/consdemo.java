class Printer
{
Printer()
{
//this("c:\\imgdir\\","training.jpeg");
System.out.println("Inside Default");

}
Printer(String path,String imgname,String fname)
{
this(fname);
//this.scanDocument();
System.out.println("Path:"+ "" +imgname); 
}


Printer(String txtfile)
{
this();
System.out.println("File"+ "" +txtfile); 

}

void scanDocument()
{
System.out.println("Scanning document");
}



}

class consdemo
{

public static void main(String a[])
{
//new Printer("abc.txt");



//new Printer();
//new Printer("c:\\imgdir\\","training.jpeg");
// Just a call to one constructor it should be able to call the other constructors automatically

new Printer("c:\\imgdir\\","training.jpeg","abc.txt");




}

}



