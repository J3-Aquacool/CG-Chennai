class ByValueAndRef
{


int nums=80;
ByValueAndRef(int nums) {
        this.nums = nums;
    }

public static void main(String a[])
{





int number=10;
System.out.println("Original value is:"+number);
printValue(number);
System.out.println("Original value is:"+number);



 updateBalance(new ByValueAndRef(100));

}


	static void printValue(int value)
	{
		value=20;
		System.out.println("after initalisation local:"+value);
	}


static void updateBalance(ByValueAndRef obj)
{
obj.nums=90;
System.out.println("after initalisation local :"+obj.nums);


}




}



