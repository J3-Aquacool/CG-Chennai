/*Inheritance:

1. Java supports single and multilevel inheritance
2. it uses a keyword "extends" for inheritance
3. Mutiple inheritnace is not supported.


Syntax

class Parent
{

}

class child extends Parent
{

}

*/


// Polymorphism: static binding(compile time) /dynamic binding(run time)


class Employee
{
Employee()
{
System.out.println("Inside Employee class");
}

Employee(String address)
{
System.out.println("Inside Employee class with address"+ address);
}

void work()
{
System.out.println(" Employee works");
}

void greetings(String name)
{
System.out.println("Welcome :"+ name);

}

void greetings(String name,String date)
{
System.out.println("Welcome :"+ name);

}
void greetings(String name,String date,String location)
{
System.out.println("Welcome :"+ name);

}


}

class Manager  extends Employee    // is-a
{

Manager()
{

super("Chenenai");

System.out.println("Inside Manager Class");

}

 void work()
{
System.out.println("Manage works");
}

}


class Clerk extends Employee    // is -a
{
void work()
	{
System.out.println(" Clerical  works");
	}
}


class call
{
public static void main(String a[])
{


//Inheritance and casting
//Manager mng=(Manager)new Employee();
//Employee emp=new Manager();// sub class can be converted to Upper level class

// Top level class cannot be converted to Lower level or sub-clas

//System.out.println(emp instanceof Manager);

Manager mng=new Manager();

//mng.work();
//mng.greetings("Lavanya");

/* Clerk clr=new  Clerk();
clr.work();
clr.greetings("Jennifer");

Employee emp=new Manager();
emp.work();
emp.greetings("All Employees");
emp.greetings("All Employees","30-Dec-2024","Chennai");
*/



/*Employee emp1=new Employee();
emp1.greetings("Hello All");
*/






}

}














